<?php

   interface AlertasMailOad {
      public function selLaqueadosNoAsignados();
      public function selPaquetesNoEnviados();
      public function selPaquetesNoLaqueados();
      public function selPendientesPasadosPrometida();
   }

?>