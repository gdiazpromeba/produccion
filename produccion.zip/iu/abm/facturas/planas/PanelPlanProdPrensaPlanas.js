PanelPlanProdPrensaPlanas = Ext.extend(Ext.Panel, {
  constructor : function(config) {
		PanelPlanProdPrensaPlanas.superclass.constructor.call(this, Ext.apply({
      layout: 'border',
      items: [
        {itemId: 'busqueda', xtype: 'busquedaplanprodprensaplanas', region: 'north'},
        {itemId: 'grilla', xtype: 'grillaplanprodprensaplanas', region: 'center'}
      ]


		}, config));
    
    var busqueda=this.getComponent('busqueda');
    var grilla=this.getComponent('grilla');
    
    busqueda.on('buscar pulsado', function(){
      var params=busqueda.getParamsBusqueda();
      grilla.recarga(params);  
    });
    
    busqueda.on('reinicializar pulsado', function(){
      grilla.getStore().baseParams=[];
      var params=[];
      grilla.recarga(params);
    });
    
    
	} //constructor
});