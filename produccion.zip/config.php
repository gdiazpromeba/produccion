<?php
  //servidor
  global $raiz; $raiz = '/home6/almarlam/public_html/produccion/';
  global $usuario; $usuario ='almarlam_gonzalo';
  global $clave; $clave ='manuela';
  global $baseDeDatos; $baseDeDatos ='almarlam_prod';

  //local
  //global $debug; $debug = true;
  //global $raiz; $raiz = 'C:/xampplite/htdocs/produccion/';
  //global $usuario; $usuario ='kallisto_gonzalo';
  //global $clave; $clave ='manuela';
  //global $baseDeDatos; $baseDeDatos ='almarlam_prod';
?>
