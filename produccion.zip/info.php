<?PHP
 
 
 
phpinfo();
 
 
 
?>